import React from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState, useEffect, useRef } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useData } from "@/lib/data-provider";
import { usePolling } from "@/lib/polling-provider";
import { ReferralNoteModal } from "@/components/referral-note-modal";
import { BackgroundCheckSettings } from "@/components/background-check-settings";
import { PollingStatusIndicator } from "@/components/polling-status-indicator";
import { PollingIntervalSelector5Min } from "@/components/polling-interval-selector-5min";
import { PollingCountdown } from "@/components/polling-countdown";
import { AutoCheckIndicator } from "@/components/auto-check-indicator";
import { fetchLaborResult, formatExamDate, getResultStatusColor, getResultStatusLabel } from "@/lib/api";
import { LaborResult } from "@/lib/types";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Haptics from "expo-haptics";

export default function ResultDetailScreen() {
  const router = useRouter();
  const colors = useColors();
  const params = useLocalSearchParams();
  const { getEntryById, addCheckHistory, addReferralNote, deleteReferralNote } =
    useData();

  const entryId = params.entryId as string;
  const entry = getEntryById(entryId);

  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showBackgroundSettings, setShowBackgroundSettings] = useState(false);
  const [loading, setLoading] = useState(false);
  const [pollingInterval, setPollingInterval] = useState(5 * 60 * 1000); // 5 minute auto-check
  const { startPollingEntry, stopPollingEntry, getPollingEntry } = usePolling();
  const pollingEntry = getPollingEntry(entryId);

  if (!entry) {
    return (
      <ScreenContainer className="flex items-center justify-center">
        <Text style={{ color: colors.foreground }}>Entry not found</Text>
        <Pressable
          onPress={() => router.back()}
          style={{ marginTop: 16 }}
        >
          <Text style={{ color: colors.primary }}>Go Back</Text>
        </Pressable>
      </ScreenContainer>
    );
  }

  const handleUpdate = async () => {
    setLoading(true);
    try {
      const result = await fetchLaborResult({
        passport_number: entry.passport_number,
        occupation_key: entry.occupation_key,
        nationality_id: entry.nationality_id,
      });

      if (result) {
        const status = result.exam_result as "passed" | "failed" | "pending";
        await addCheckHistory(entryId, result, status);
        await Haptics.notificationAsync(
          Haptics.NotificationFeedbackType.Success
        );
        Alert.alert("Success", "Status updated successfully");
      }
    } catch (error) {
      await Haptics.notificationAsync(
        Haptics.NotificationFeedbackType.Error
      );
      Alert.alert("Error", "Failed to update status");
    } finally {
      setLoading(false);
    }
  };

  const handleAddNote = async (note: string) => {
    await addReferralNote(entryId, note);
    await Haptics.notificationAsync(
      Haptics.NotificationFeedbackType.Success
    );
  };

  const handleStartPolling = () => {
    if (!entry) return;
    startPollingEntry(
      entryId,
      entry.passport_number,
      entry.occupation_key,
      entry.nationality_id,
      pollingInterval
    );
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleStopPolling = () => {
    stopPollingEntry(entryId);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const lastResultRef = useRef<LaborResult | null>(null);

  useEffect(() => {
    if (pollingEntry?.lastResult && lastResultRef.current !== pollingEntry.lastResult) {
      lastResultRef.current = pollingEntry.lastResult;
      const status = pollingEntry.lastResult.exam_result as "passed" | "failed" | "pending";
      addCheckHistory(entryId, pollingEntry.lastResult, status);
    }
  }, [pollingEntry?.lastResult, entryId, addCheckHistory]);

  const handleDeleteNote = (noteId: string) => {
    Alert.alert("Delete Note", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        onPress: async () => {
          await deleteReferralNote(entryId, noteId);
        },
        style: "destructive",
      },
    ]);
  };

  const result = entry.latest_result;
  const lastCheckTime = entry.last_checked_at
    ? new Date(entry.last_checked_at).toLocaleString()
    : "Never";

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 12,
            borderBottomWidth: 1,
            borderBottomColor: colors.border,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
          >
            <MaterialIcons
              name="arrow-back"
              size={24}
              color={colors.primary}
            />
          </Pressable>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "600",
              color: colors.foreground,
              marginLeft: 12,
              flex: 1,
            }}
          >
            Result Details
          </Text>
        </View>

        {/* Content */}
        <View style={{ paddingHorizontal: 16, paddingVertical: 20 }}>
          {result ? (
            <>
              {/* Status Card */}
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 12,
                  padding: 20,
                  marginBottom: 20,
                  borderWidth: 1,
                  borderColor: colors.border,
                  alignItems: "center",
                }}
              >
                <MaterialIcons
                  name={
                    result.exam_result === "passed"
                      ? "check-circle"
                      : result.exam_result === "failed"
                      ? "cancel"
                      : "schedule"
                  }
                  size={48}
                  color={getResultStatusColor(result.exam_result as "passed" | "failed" | "pending")}
                />
                <Text
                  style={{
                    fontSize: 24,
                    fontWeight: "700",
                    color: getResultStatusColor(result.exam_result as "passed" | "failed" | "pending"),
                    marginTop: 12,
                  }}
                >
                  {getResultStatusLabel(result.exam_result as "passed" | "failed" | "pending")}
                </Text>
              </View>

              {/* Details */}
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 20,
                  borderWidth: 1,
                  borderColor: colors.border,
                  gap: 12,
                }}
              >
                <DetailRow
                  label="Passport Number"
                  value={entry.passport_number}
                  colors={colors}
                />
                <DetailRow
                  label="Exam Date"
                  value={formatExamDate(result.exam_date)}
                  colors={colors}
                />
                <DetailRow
                  label="Test Center"
                  value={result.test_center_name}
                  colors={colors}
                />
                <DetailRow
                  label="Occupation Code"
                  value={entry.occupation_key}
                  colors={colors}
                />
                <DetailRow
                  label="Nationality"
                  value={entry.nationality_id}
                  colors={colors}
                />
              </View>

              {/* History Info */}
              <View
                style={{
                  backgroundColor: colors.surface,
                  borderRadius: 12,
                  padding: 16,
                  marginBottom: 20,
                  borderWidth: 1,
                  borderColor: colors.border,
                  gap: 8,
                }}
              >
                <DetailRow
                  label="Last Checked"
                  value={lastCheckTime}
                  colors={colors}
                />
                <DetailRow
                  label="Total Checks"
                  value={entry.check_count.toString()}
                  colors={colors}
                />
              </View>

              {/* Referral Notes */}
              <View style={{ marginBottom: 20 }}>
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginBottom: 12,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      color: colors.foreground,
                    }}
                  >
                    Referral Notes ({entry.referral_notes.length})
                  </Text>
                  <Pressable
                    onPress={() => setShowNoteModal(true)}
                    style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
                  >
                    <MaterialIcons
                      name="add-circle"
                      size={24}
                      color={colors.primary}
                    />
                  </Pressable>
                </View>

                {entry.referral_notes.length > 0 ? (
                  entry.referral_notes.map((note) => (
                    <View
                      key={note.id}
                      style={{
                        backgroundColor: colors.surface,
                        borderRadius: 8,
                        padding: 12,
                        marginBottom: 8,
                        borderLeftWidth: 4,
                        borderLeftColor: colors.primary,
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                      }}
                    >
                      <View style={{ flex: 1 }}>
                        <Text
                          style={{
                            color: colors.foreground,
                            fontSize: 14,
                            marginBottom: 4,
                          }}
                        >
                          {note.content}
                        </Text>
                        <Text
                          style={{
                            color: colors.muted,
                            fontSize: 12,
                          }}
                        >
                          {new Date(note.timestamp).toLocaleString()}
                        </Text>
                      </View>
                      <Pressable
                        onPress={() => handleDeleteNote(note.id)}
                        style={({ pressed }) => [
                          { opacity: pressed ? 0.6 : 1 },
                          { marginLeft: 8 },
                        ]}
                      >
                        <MaterialIcons
                          name="close"
                          size={20}
                          color={colors.error}
                        />
                      </Pressable>
                    </View>
                  ))
                ) : (
                  <Text
                    style={{
                      color: colors.muted,
                      fontSize: 14,
                      fontStyle: "italic",
                    }}
                  >
                    No referral notes yet
                  </Text>
                )}
              </View>

              {/* Auto-Check Indicator */}
              {pollingEntry?.isPolling && (
                <AutoCheckIndicator
                  isActive={pollingEntry.isPolling}
                  lastCheckTime={pollingEntry.lastResult ? Date.now() : null}
                  nextCheckTime={pollingEntry.lastResult ? Date.now() + pollingInterval : null}
                />
              )}

              {/* Polling Status */}
              {pollingEntry && (
                <View style={{ marginBottom: 20 }}>
                  <PollingStatusIndicator
                    status={pollingEntry.status}
                    lastFetchTime={pollingEntry.lastResult ? Date.now() : null}
                    retryCount={0}
                    error={pollingEntry.lastError?.message}
                  />
                  <PollingCountdown
                    isPolling={pollingEntry.isPolling}
                    intervalMs={pollingInterval}
                    lastFetchTime={pollingEntry.lastResult ? Date.now() : null}
                  />
                </View>
              )}

              {/* Polling Status - 5 Minute Auto Check */}
              {pollingEntry?.isPolling && (
                <View style={{ marginBottom: 20 }}>
                  <PollingIntervalSelector5Min
                    isEnabled={pollingEntry.isPolling}
                    onToggle={(enabled) => {
                      if (!enabled) {
                        handleStopPolling();
                      }
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    }}
                  />
                </View>
              )}

              {/* Actions */}
              <View style={{ gap: 12, marginBottom: 20 }}>
                <Pressable
                  onPress={handleUpdate}
                  disabled={loading}
                  style={({ pressed }) => [
                    {
                      backgroundColor: colors.primary,
                      paddingVertical: 12,
                      borderRadius: 8,
                      alignItems: "center",
                      opacity: pressed || loading ? 0.7 : 1,
                    },
                  ]}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text
                      style={{
                        color: "#fff",
                        fontSize: 16,
                        fontWeight: "600",
                      }}
                    >
                      Update Status
                    </Text>
                  )}
                </Pressable>

                <Pressable
                  onPress={!pollingEntry?.isPolling ? handleStartPolling : handleStopPolling}
                  style={({ pressed }) => [{
                    backgroundColor: pollingEntry?.isPolling ? colors.error : colors.primary,
                    paddingVertical: 12,
                    borderRadius: 8,
                    alignItems: "center",
                    opacity: pressed ? 0.7 : 1,
                  }]}
                >
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                    <MaterialIcons
                      name={pollingEntry?.isPolling ? "star" : "star-outline"}
                      size={20}
                      color="#fff"
                    />
                    <Text style={{ color: "#fff", fontSize: 16, fontWeight: "600" }}>
                      {pollingEntry?.isPolling ? "Stop Auto-Check" : "Start Auto-Check"}
                    </Text>
                  </View>
                </Pressable>


              </View>

              {showBackgroundSettings && (
                <View style={{ marginBottom: 20 }}>
                  <BackgroundCheckSettings
                    entryId={entryId}
                    passportNumber={entry.passport_number}
                  />
                </View>
              )}
            </>
          ) : (
            <Text style={{ color: colors.foreground }}>
              No result available
            </Text>
          )}
        </View>
      </ScrollView>

      <ReferralNoteModal
        visible={showNoteModal}
        onClose={() => setShowNoteModal(false)}
        onSave={handleAddNote}
      />
    </ScreenContainer>
  );
}

function DetailRow({
  label,
  value,
  colors,
}: {
  label: string;
  value: string;
  colors: any;
}) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <Text style={{ color: colors.muted, fontSize: 14 }}>{label}:</Text>
      <Text
        style={{
          color: colors.foreground,
          fontSize: 14,
          fontWeight: "600",
          flex: 1,
          textAlign: "right",
        }}
      >
        {value}
      </Text>
    </View>
  );
}
