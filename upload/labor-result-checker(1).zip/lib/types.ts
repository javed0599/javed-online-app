/**
 * API Response types for the labor result checker
 */

export interface LaborResult {
  exam_date: string;
  exam_result: "passed" | "failed" | "pending";
  exam_result_id: number;
  test_center_name: string;
}

export interface PassportEntry {
  id: string;
  passport_number: string;
  occupation_key: string;
  nationality_id: string;
  latest_result: LaborResult | null;
  check_history: CheckHistory[];
  referral_notes: ReferralNote[];
  created_at: number;
  last_checked_at: number | null;
  check_count: number;
}

export interface CheckHistory {
  id: string;
  timestamp: number;
  result: LaborResult;
  status: "passed" | "failed" | "pending";
}

export interface ReferralNote {
  id: string;
  timestamp: number;
  content: string;
  created_at: number;
}

export interface ApiParams {
  passport_number: string;
  occupation_key: string;
  nationality_id?: string;
  locale?: string;
}

export interface NotificationLog {
  id: string;
  timestamp: number;
  passportNumber: string;
  entryId: string;
  previousStatus: "passed" | "failed" | "pending";
  currentStatus: "passed" | "failed" | "pending";
  testCenterName: string;
  examDate: string;
  read: boolean;
}

export interface NotificationSettings {
  id: string;
  soundEnabled: boolean;
  soundType: "default" | "chime" | "bell" | "notification" | "silent";
  vibrationEnabled: boolean;
  vibrationPattern: "light" | "medium" | "heavy";
  quietHoursEnabled: boolean;
  quietHoursStart: string;
  quietHoursEnd: string;
  notificationsEnabled: boolean;
}

export interface EntryNotificationPreferences {
  entryId: string;
  soundEnabled?: boolean;
  vibrationEnabled?: boolean;
  notificationsEnabled: boolean;
  muteUntil?: number;
}
