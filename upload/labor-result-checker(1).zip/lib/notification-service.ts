import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export interface NotificationPayload {
  passportNumber: string;
  previousStatus?: string;
  newStatus: string;
  testCenter?: string;
  examDate?: string;
  timestamp: string;
}

/**
 * Send a local notification when result status changes
 */
export async function sendStatusNotification(payload: NotificationPayload) {
  try {
    const statusEmoji = {
      passed: '✅',
      failed: '❌',
      pending: '⏳',
    };

    const emoji = statusEmoji[payload.newStatus as keyof typeof statusEmoji] || '📋';
    const title = `${emoji} Result Status Update`;
    
    let body = `Passport: ${payload.passportNumber}\n`;
    
    if (payload.previousStatus && payload.previousStatus !== payload.newStatus) {
      body += `Status: ${payload.previousStatus} → ${payload.newStatus}\n`;
    } else {
      body += `Status: ${payload.newStatus}\n`;
    }
    
    if (payload.testCenter) {
      body += `Center: ${payload.testCenter}\n`;
    }
    
    if (payload.examDate) {
      body += `Date: ${payload.examDate}`;
    }

    // Send local notification
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
        badge: 1,
        data: {
          passportNumber: payload.passportNumber,
          status: payload.newStatus,
          timestamp: payload.timestamp,
        },
      },
      trigger: null, // Send immediately
    });

    console.log('🔔 [Notification] Status notification sent:', {
      passport: payload.passportNumber,
      status: payload.newStatus,
      timestamp: payload.timestamp,
    });
  } catch (error) {
    console.error('🔔 [Notification] Failed to send notification:', error);
  }
}

/**
 * Request notification permissions from user
 */
export async function requestNotificationPermissions() {
  try {
    if (Platform.OS === 'web') {
      console.log('🔔 [Notification] Notifications not supported on web');
      return false;
    }

    const { status } = await Notifications.requestPermissionsAsync();
    const hasPermission = status === 'granted';

    console.log('🔔 [Notification] Permission status:', status);
    return hasPermission;
  } catch (error) {
    console.error('🔔 [Notification] Failed to request permissions:', error);
    return false;
  }
}

/**
 * Get current notification permissions status
 */
export async function getNotificationPermissions() {
  try {
    if (Platform.OS === 'web') {
      return false;
    }

    const { status } = await Notifications.getPermissionsAsync();
    return status === 'granted';
  } catch (error) {
    console.error('🔔 [Notification] Failed to get permissions:', error);
    return false;
  }
}

/**
 * Send test notification
 */
export async function sendTestNotification() {
  try {
    const hasPermission = await getNotificationPermissions();
    
    if (!hasPermission) {
      console.log('🔔 [Notification] No permission to send notifications');
      return false;
    }

    await Notifications.scheduleNotificationAsync({
      content: {
        title: '✅ Test Notification',
        body: 'This is a test notification from JAVED ONLINE',
        sound: 'default',
        badge: 1,
      },
      trigger: null,
    });

    console.log('🔔 [Notification] Test notification sent');
    return true;
  } catch (error) {
    console.error('🔔 [Notification] Failed to send test notification:', error);
    return false;
  }
}

/**
 * Clear all notifications
 */
export async function clearAllNotifications() {
  try {
    await Notifications.dismissAllNotificationsAsync();
    console.log('🔔 [Notification] All notifications cleared');
  } catch (error) {
    console.error('🔔 [Notification] Failed to clear notifications:', error);
  }
}

/**
 * Set up notification listeners
 */
export function setupNotificationListeners(
  onNotificationReceived?: (notification: Notifications.Notification) => void,
  onNotificationTapped?: (response: Notifications.NotificationResponse) => void
) {
  // Listen for notifications when app is in foreground
  const foregroundSubscription = Notifications.addNotificationReceivedListener((notification) => {
    console.log('🔔 [Notification] Received in foreground:', notification);
    onNotificationReceived?.(notification);
  });

  // Listen for notification taps
  const backgroundSubscription = Notifications.addNotificationResponseReceivedListener((response) => {
    console.log('🔔 [Notification] User tapped notification:', response);
    onNotificationTapped?.(response);
  });

  // Return cleanup function
  return () => {
    foregroundSubscription.remove();
    backgroundSubscription.remove();
  };
}
