import React from "react";
import { View, Text, Pressable, StyleSheet, ActivityIndicator } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { formatExamDate, getResultStatusColor, getResultStatusLabel } from "@/lib/api";
import { LaborResult } from "@/lib/types";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { usePolling } from "@/lib/polling-provider";
import { Share } from "react-native";

interface ResultCardProps {
  result: LaborResult;
  passportNumber: string;
  entryId?: string;
  onPress?: () => void;
  onDelete?: () => void;
  onUpdate?: () => void;
  onShare?: () => void;
}

export function ResultCard({
  result,
  passportNumber,
  entryId,
  onPress,
  onDelete,
  onUpdate,
  onShare,
}: ResultCardProps) {
  const colors = useColors();
  const { getPollingEntry } = usePolling();
  const pollingEntry = entryId ? getPollingEntry(entryId) : undefined;
  
  // Use polling result if available, otherwise use provided result
  const displayResult = pollingEntry?.lastResult || result;
  const statusColor = getResultStatusColor(displayResult.exam_result);
  const statusLabel = getResultStatusLabel(displayResult.exam_result);
  const formattedDate = formatExamDate(displayResult.exam_date);
  const isPolling = pollingEntry?.isPolling;

  const handleShare = async () => {
    const message = `Labor Result for ${passportNumber}\n\nStatus: ${statusLabel}\nExam Date: ${formattedDate}\nTest Center: ${displayResult.test_center_name}`;
    try {
      await Share.share({
        message: message,
        title: "Share Labor Result",
      });
    } catch (error) {
      console.error("Share failed:", error);
    }
  };

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.container,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          opacity: pressed ? 0.7 : 1,
        },
      ]}
    >
      <View style={styles.header}>
        <View style={styles.statusBadge}>
          {isPolling ? (
            <ActivityIndicator size={24} color={colors.primary} />
          ) : (
            <MaterialIcons
              name={displayResult.exam_result === "passed" ? "check-circle" : displayResult.exam_result === "failed" ? "cancel" : "schedule"}
              size={24}
              color={statusColor}
            />
          )}
          <Text style={[styles.statusText, { color: statusColor }]}>
            {statusLabel}
          </Text>
        </View>
        <View style={styles.actions}>
          <Pressable
            onPress={handleShare}
            style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }]}
          >
            <MaterialIcons name="share" size={20} color={colors.primary} />
          </Pressable>
          {onUpdate && (
            <Pressable
              onPress={onUpdate}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }, { marginLeft: 12 }]}
            >
              <MaterialIcons name="refresh" size={20} color={colors.primary} />
            </Pressable>
          )}
          {onDelete && (
            <Pressable
              onPress={onDelete}
              style={({ pressed }) => [{ opacity: pressed ? 0.6 : 1 }, { marginLeft: 12 }]}
            >
              <MaterialIcons name="delete" size={20} color={colors.error} />
            </Pressable>
          )}
        </View>
      </View>

      <View style={styles.content}>
        <View style={styles.row}>
          <Text style={[styles.label, { color: colors.muted }]}>
            Passport Number:
          </Text>
          <Text style={[styles.value, { color: colors.foreground }]}>
            {passportNumber}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={[styles.label, { color: colors.muted }]}>
            Exam Date:
          </Text>
          <Text style={[styles.value, { color: colors.foreground }]}>
            {formattedDate}
          </Text>
        </View>

        <View style={styles.row}>
          <Text style={[styles.label, { color: colors.muted }]}>
            Test Center:
          </Text>
          <Text style={[styles.value, { color: colors.foreground }]}>
            {displayResult.test_center_name}
          </Text>
        </View>
        
        {isPolling && (
          <View style={[styles.row, { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.border }]}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <MaterialIcons name="sync" size={14} color={colors.primary} />
              <Text style={[styles.label, { color: colors.primary }]}>
                Auto-checking every 5 min
              </Text>
            </View>
          </View>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  statusText: {
    fontSize: 16,
    fontWeight: "600",
  },
  actions: {
    flexDirection: "row",
    gap: 8,
  },
  content: {
    gap: 8,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  label: {
    fontSize: 12,
    fontWeight: "500",
  },
  value: {
    fontSize: 14,
    fontWeight: "600",
  },
});
